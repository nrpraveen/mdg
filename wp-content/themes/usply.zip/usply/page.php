<?
the_post();
get_header();
//get_hero();
//partial('section.main', ['widgets' => get_page_widgets()]);
get_footer();