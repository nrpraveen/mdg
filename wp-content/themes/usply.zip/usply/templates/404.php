<?
the_post();
get_header();
get_hero();
get_footer();