<?
# Template Name: Home
the_post();
get_header();
partial('widget.slider');
partial('section.main');
get_footer();