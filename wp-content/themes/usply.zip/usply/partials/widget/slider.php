<?
global $website_settings;
wp_enqueue_script('internal-widget-slider');

?>
<div class="widget slider">
	<div class="content">
		Slider
	</div>
</div>