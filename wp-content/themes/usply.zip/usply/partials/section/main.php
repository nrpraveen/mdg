<section>
	<div class="content">
		<article>
			Article
		</article>
		<aside>
			<div class="widgets">
				Sidebar
			</div>
		</aside>
	</div>
</section>