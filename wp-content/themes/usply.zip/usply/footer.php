	
		</div>
		<?
		
		//partial('section.footer');
		//partial('section.copyright', [
		//	'show_trademark' => (is_page() && (bool)get_post_meta(get_the_ID(), 'page_trademark_footer', true)),
		//]); 
		wp_footer();
		?>
	</body>
</html>